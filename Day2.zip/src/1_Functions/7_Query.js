// var obj = { // does not create a new scope
//     i: 10,
//     b: () => {
//         console.log(this.i, this)
//     },
//     c: function () {
//         console.log(this.i, this);
//     }
// }

// obj.b();
// obj.c();


window.age = 10; // <-- notice me?
function Person() {
    this.age = 42; // <-- notice me?
    setTimeout(() => { // <-- Arrow function executing in the "p" (an instance of Person) scope
        console.log("this.age", this.age); // yields "42" because the function executes on the Person scope
    }, 100);
}
var p = new Person();