var map = new Map();
var wmap = new WeakMap();

map.set('the string', 'This is the value for first key');

// WeakMap - key is always an object
const o = { id: 1 };
wmap.set(o, 'This is the value for first key');

console.log(wmap.get(o));

// for (const item of map) {
//     console.log(item);
// }

// WeakMap is not iterable
// for (const item of wmap) {
//     console.log(item);
// }