// var employees = new Array();
// var employees = new Array(2);
// var employees = new Array("ABC", "PQR");
// var employees = new Array(2,4);
// var employees = new Array([1, 2, 4, 8]);
// var employees = new Array("Manish");
// var employees = Array.from("Manish");
// var employees = Array.from([1, 2, 4, 8]);
// var employees = Array.of(2);

// var employees = [];

// employees[0] = "ABC";
// employees[1] = "XYZ";
// employees[2] = "PQR";

// employees.push("Manish");
// employees.unshift("Abhijeet");

// console.log(employees);
// console.log(employees.length);

// --------------------------------------------------- Iterate

var employees = [
    { id: 1, name: "Manish" },
    { id: 2, name: "Varun" },
    { id: 3, name: "Paresh" },
    { id: 4, name: "Devesh" },
    { id: 5, name: "Atul" },
    { id: 6, name: "Abhishek" }
];

// for (let i = 0; i < employees.length; i++) {
//     console.log(`${i}       ${JSON.stringify(employees[i])}`);
// }

// for (const key in employees) {
//     console.log(`${key}       ${JSON.stringify(employees[key])}`);
// }

// employees.forEach((item, index, arr) => {
//     console.log(`${index}       ${JSON.stringify(item)}`);
// });

// for (const item of employees) {
//     console.log(`${JSON.stringify(item)}`);
// }

// for (const item of employees.entries()) {
//     console.log(`${JSON.stringify(item)}`);
// }

// for (const [index, item] of employees.entries()) {
//     console.log(`${index}       ${JSON.stringify(item)}`);
// }

// var filtered = employees.filter(item => item.name.startsWith('A'));
// console.log(filtered);

// var mapped = employees.map(item => item.name.toUpperCase());
// console.log(mapped);

// var numbers = [10, 20, 30, 40, 50];

// const reducerFn = function (accumulator, item) {
//     // console.log(accumulator);
//     return accumulator + item;
// }

// console.log(numbers.reduce(reducerFn));

// console.log(numbers.reduce((a, i) => a + i));

// var filtered = employees.filter(item => item.id === 1);
// console.log(filtered);

// var result = employees.find(item => item.id === 1);
// console.log(result);

var result = employees.findIndex(item => item.id === 3);
console.log(result);