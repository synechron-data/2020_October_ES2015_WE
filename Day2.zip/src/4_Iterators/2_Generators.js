function* idGenerator() {
    yield 1;
    yield 2;
    yield 3;
    yield 4;
}

let seq = idGenerator();
// console.log(seq);

for (let i = 0; i < 5; i++) {
    console.log(seq.next());
}