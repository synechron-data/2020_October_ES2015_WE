import localAPI from './localAPI.js';

var button = document.createElement("button");
button.innerHTML = "Get Data";

var body = document.getElementsByTagName("body")[0];
body.appendChild(button);

button.addEventListener("click", function () {
    // console.log("Button Clicked....");

    // localAPI.getAllPosts((data) => {
    //     console.log(data);
    // }, (eMsg) => {
    //     console.error(eMsg);
    // });

    localAPI.getAllPostsUsingPromise().then((data) => {
        console.log(data);
    }, (eMsg) => {
        console.error(eMsg);
    });
});