var language;
console.log("Language is: ", language);
console.log("Type of Language is: ", typeof language);

language = null;
console.log("Language is: ", language);
console.log("Type of Language is: ", typeof language);

// language = 10;           // Base 10 (Decimal)
// language = 10.5;
// language = 0b1001;      // Base 2 (Binary)
// language = 0o1001;      // Base 8 (Octal)
// language = 0x1001;      // Base 16 (Hex)
language = Number("100")     
console.log("Language is: ", language);
console.log("Type of Language is: ", typeof language);

// language = "JavaScript";
// language = 'JavaScript';

// ECMAScript 2015 - Template (String) Literals

language = `Java

Script`;

console.log("Language is: ", language);
console.log("Type of Language is: ", typeof language);

language = true;
console.log("Language is: ", language);
console.log("Type of Language is: ", typeof language);


// ECMAScript 2015 - Symbol
language = Symbol("Hello");
console.log("Language is: ", language);
console.log("Type of Language is: ", typeof language);

// language = Object();
language = new Object();
console.log("Language is: ", language);
console.log("Type of Language is: ", typeof language);

language = String(10);
console.log("Language is: ", language);
console.log("Type of Language is: ", typeof language);

language = new String(10);
console.log("Language is: ", language);
console.log("Type of Language is: ", typeof language);

language = new Date();
console.log("Language is: ", language);
console.log("Type of Language is: ", typeof language);
